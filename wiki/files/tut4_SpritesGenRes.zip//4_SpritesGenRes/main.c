#include <genesis.h>

struct genresSprites
{
		u16 *pal; 		//pointer to pal data
		u32 **sprites;		//pointer to sprites data
		u16 count;		//nb sprites
		u16 width;		//width of each sprite in pixels
		u16 height;		//height of each sprite in pixels
		u16 size; 		//since we use width/height in pixel, useful info on sprite size
						//TODO : size is not SGDK compliant, you need to use size>>8
						//		will be fixed in coming release
};
extern struct genresSprites sonic;


#define TILE1	1

int main( )
{
	_spritedef mySprite;
	u16 nbTiles = (sonic.height>>3) * (sonic.width>>3);
	u8 frame = 0;

	//load the tile in VRAM (check it using GensKMod CPU>Debug>Genesis>VDP)
	VDP_loadTileData( sonic.sprites[0], TILE1, nbTiles, 0);
	//VDP_loadTileData( sonic.sprites[1], TILE1+nbTiles, nbTiles, 0);

	VDP_setPalette(PAL1, sonic.pal);

	//optional, but take the use to
	VDP_resetSprites();

	// Try 1 : define sonic using setSprite
	// arg0 : sprite idx (from 0 to 79)
	// arg1 : x
	// arg2 : y
	// arg3 : size (from 1x1 to 4x4 tiles)
	// arg4 : tiles properties
	// arg5 : link property
	VDP_setSprite(0, 0, 0, sonic.size>>8, TILE_ATTR_FULL(PAL1,1,0,0,TILE1), 1 /* 0 */);

	// Try 2: flipped
	VDP_setSprite(1, VDP_getScreenWidth()-sonic.width, 0, sonic.size>>8, TILE_ATTR_FULL(PAL1,1,0,1,TILE1), 2 /*0*/);

	// Try 3: define sonic run anim using setSprite
	//VDP_setSprite(2, 40, 40, sonic.size>>8, TILE_ATTR_FULL(PAL1,1,0,0,TILE1+nbTiles), 0);

	// Try 4 : make it move
	mySprite.posx = 40;
	mySprite.posy = 40;
	mySprite.size = sonic.size>>8;
	mySprite.tile_attr = TILE_ATTR_FULL(PAL1,1,0,0,TILE1+nbTiles);
	mySprite.link  = 0;
	VDP_setSpriteP(2, &mySprite);

	VDP_updateSprites();

	while(1)
	{
		//we update VRAM not sprite to produce animation (avoid to load each frame on VRAM)
		VDP_loadTileData( sonic.sprites[frame + 1], TILE1+nbTiles, nbTiles, 0);
		frame++;
		frame%=3;


		mySprite.posx+=10;
		VDP_setSpriteP(2, &mySprite);
		VDP_updateSprites();

		VDP_waitVSync();
		VDP_waitVSync();
		VDP_waitVSync();
	}
	return 0;
}
