#include <genesis.h>


struct genresTiles
{
		u16 *pal; 		//pointer to pal data
		u32 *tiles;		//pointer to tiles data
		u16 width;		//width in tiles
		u16 height;		//height in tiles
		u16 compressedSize; //0 in this demo, more coming soon
};
extern struct genresTiles moon;

#define TILE1	1

int main( )
{
	VDP_setPalette(PAL1, moon.pal);

	// load tiles in VRAM
	//  arg0 = tiles data
	//  arg1 = index for first destination tile
	//  arg2 = number of tiles to load
	//  arg3 = use DMA (1) or not (0)
	VDP_loadTileData(moon.tiles, TILE1, moon.width*moon.height, 0);

	VDP_fillTileMapRectInc(BPLAN, TILE_ATTR_FULL(PAL1, 0, 0, 0, TILE1), 12, 12, moon.width, moon.height);

	while(1)
	{
		VDP_waitVSync();
	}
	return 0;
}
