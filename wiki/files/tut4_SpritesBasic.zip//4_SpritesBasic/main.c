#include <genesis.h>

#define TILE1	1
#define SPR_NBTILES	4	//tiles needed for our sprite

//const is used to keep tile in ROM, not in RAM
const u32 spriteTiles[SPR_NBTILES*8]=
{
		0x00001111, //Tile Top Left
		0x00001111,
		0x00111144,
		0x00111144,
		0x11112244,
		0x11112244,
		0x11112244,
		0x11112244,

		0x11112222, //Tile Bottom Left
		0x11112222,
		0x11112222,
		0x11112222,
		0x00111122,
		0x00111122,
		0x00001111,
		0x00001111,

		0x11110000, //Tile Top Right
		0x11110000,
		0x44111100,
		0x44111100,
		0x44221111,
		0x44221111,
		0x44221111,
		0x44221111,

		0x22221111, //Tile Bottom Right
		0x22221111,
		0x22221111,
		0x22221111,
		0x22111100,
		0x22111100,
		0x11110000,
		0x11110000
};

int main( )
{
	_spritedef mySprite;
	_spritedef mySprite2;
	_spritedef mySprite3;

	//load the tile in VRAM (check it using GensKMod CPU>Debug>Genesis>VDP)
	VDP_loadTileData( (const u32 *)spriteTiles, TILE1, 4, 0);

	//optional, but take the use to
	VDP_resetSprites();

	// Try 1 : define sprite using setSprite
	// arg0 : sprite idx (from 0 to 79)
	// arg1 : x
	// arg2 : y
	// arg3 : size (from 1x1 to 4x4 tiles)
	// arg4 : tiles properties
	// arg5 : link property (more on this later)
	//VDP_setSprite(0, 0, 0, SPRITE_SIZE(2,2), TILE_ATTR_FULL(PAL0,1,0,0,TILE1), 0);


	// Try 2 : define sprite using setSpriteP
	mySprite.posx = 0;
	mySprite.posy = 0;
	mySprite.size = SPRITE_SIZE(2,2);
	mySprite.tile_attr = TILE_ATTR_FULL(PAL0,1,0,0,TILE1);
	mySprite.link  = 2; //1; //0;
	VDP_setSpriteP(0, &mySprite);

	//the sprite(s) won't be drawn until this call
	//VDP_updateSprites();

	// Try 3 : define multi sprite
	mySprite2.posx = 0;
	mySprite2.posy = 0;
	mySprite2.size = SPRITE_SIZE(1,1); //a sprite 1x1 using 1 tile
	mySprite2.tile_attr = TILE_ATTR_FULL(PAL0,1,0,0,TILE1);
	mySprite2.link  = 2;
	VDP_setSpriteP(1, &mySprite2);
	//VDP_updateSprites();

	// Try 4 : skip mySprite2
	mySprite3.posx = 0;
	mySprite3.posy = 0;
	mySprite3.size = SPRITE_SIZE(2,2);
	mySprite3.tile_attr = TILE_ATTR_FULL(PAL1,1,0,0,TILE1);
	mySprite3.link  = 0;
	VDP_setSpriteP(2, &mySprite3);

	VDP_updateSprites();



	while(1)
	{
		VDP_waitVSync();

		VDP_resetSprites();

		mySprite.posx++;
		mySprite.posy++;
		VDP_setSpriteP(0, &mySprite);

		mySprite2.posx+=2;
		mySprite2.posy++;
		VDP_setSpriteP(1, &mySprite2);

		mySprite3.posx++;
		mySprite3.posy+=2;
		VDP_setSpriteP(2, &mySprite3);

		VDP_updateSprites();

	}
	return 0;
}
