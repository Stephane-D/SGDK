#include <genesis.h>

//moon.h is generated from moon.bmp
//just be sure to put your 16colors bitmap on 'res' folder
// file logo-blue-moon-25024.jpg is here for reference : it's the original picture I used
#include "moon.h"

#define TILE1	1


int main( )
{
	// get the image width (in pixel) ==> should be 8pix aligned
	u16 w = moon[0];
	// get the image height (in pixel)  ==> should be 8px aligned
	u16 h = moon[1];

	// get the palette at moon[2 to 17]
	VDP_setPalette(PAL1, (u16 *) &moon[2]);

	// load bitmap data at moon[18....] in VRAM
	// w/8 = width in tiles we want to load
	// h/8 = height in tile we want to load
	// w/8 = width in tiles of the bitamp
	// the 3rd arg is needed because you could load only a part of the bitmap if you want but SGDK needs the width as reference
	VDP_loadBMPTileData((u32*) &moon[18], TILE1, w/8, h/8, w/8);

	// draw the moon at (12,12)
	VDP_fillTileMapRectInc(BPLAN, TILE_ATTR_FULL(PAL1, 0, 0, 0, TILE1), 12, 12, w/8, h/8);

	while(1)
	{
		VDP_waitVSync();
	}
	return 0;
}
